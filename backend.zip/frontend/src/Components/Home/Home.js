import React from 'react'
import Nav from './Nav/Nav'

function Home() {
  return (
   
    <div>
         <Nav/>
        Home</div>
  )
}

export default Home