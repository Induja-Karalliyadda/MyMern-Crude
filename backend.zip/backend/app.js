const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const User = require("./Model/UserModel"); // Make sure you have the User model in the correct path
const router = require("./Routes/UserRoutes"); // insert route

const app = express();

// Middleware
app.use(express.json());
app.use(cors());
app.use("/", router);

// Connect to the DB
mongoose
  .connect("mongodb+srv://admin:VRwPd89iaW0dqrd0@cluster0.d0qw4rz.mongodb.net/")
  .then(() => console.log("Connected to MongoDB"))
  .then(() => {
    app.listen(5000, () => {
      console.log("Server is running on port 5000");
    });
  })
  .catch((err) => console.log(err));

// Login-----------------------------------
app.post("/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email }); // Corrected typo from 'awit' to 'await'
    if (!user) {
      return res.json({ error: "User not found" });
    }
    if (user.password === password) {
      return res.json({ status: "ok" });
    } else {
      return res.json({ status: "incorrect password" });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
});